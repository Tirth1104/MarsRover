MARS ROVER SIMULATION
=====================

Overview
--------
This is a Java-based simulation of a Mars Rover navigating a grid. 
The rover can move forward, turn left, or turn right while avoiding obstacles. 
The simulation provides a final status report after executing a sequence of commands. 

The project uses an object-oriented design with separate classes for the rover, 
commands, grid, obstacles, and directions.

Design Pattens used here

Pattern	                                               Purpose	                                                                                                                   Where

Singleton	                                                One instance per direction	                                                                                        North, East, South, West
Command	                                               Encapsulate rover actions	                                                                                        Command interface & concrete commands
Strategy	                                               Dynamic movement behavior based on direction                                                          	Direction interface & implementations
Factory / Parser	                                        Create command objects from input	                                                                        CommandParser
Composite (light)	                                 Uniform treatment of obstacles in grid	                                                                GridComponent, Obstacle, Grid

Project Structure
-----------------
src/
├── com/EduIni/marsrover/
│   ├── Main.java
│   ├── core/
│   │   └── Rover.java
│   ├── commands/
│   │   ├── Command.java
│   │   ├── MoveCommand.java
│   │   ├── TurnLeftCommand.java
│   │   └── TurnRightCommand.java
│   ├── grid/
│   │   ├── Grid.java
│   │   └── Obstacle.java
│   ├── model/
│   │   ├── Position.java
│   │   ├── Direction.java
│   │   ├── North.java
│   │   ├── East.java
│   │   ├── South.java
│   │   └── West.java
│   ├── util/
│   │   └── CommandParser.java
│   └── exception/
│       └── ObstacleDetectedException.java

How to Run
----------
1. Compile all Java files:
   javac -d bin src/com/EduIni/marsrover/**/*.java

2. Run the simulation:
   java -cp bin com.EduIni.marsrover.Main

Input
-----
The program will prompt for:
1. Grid size: width and height (e.g., 10 10)
2. Number of obstacles and their coordinates (e.g., 2 → (2,2) and (3,5))
3. Starting position of the rover (X, Y, Direction: N/E/S/W)
4. Command sequence (string of M, L, R)

Example Input:
----------------
Enter grid width: 10
Enter grid height: 10
Enter number of obstacles: 2
Enter obstacle 1 (x y): 2 2
Enter obstacle 2 (x y): 3 5
Enter starting X: 0
Enter starting Y: 0
Enter starting direction (N/E/S/W): N
Enter command string (M=Move, L=Left, R=Right): MMRMLM

Output
------
After executing the commands, the program prints:
- Rover initialized position
- Final position and direction
- Status report

Example Output:
----------------
Rover initialized at Position[x=0, y=0] facing N
Final Position: (1, 3, E)
Status Report: Rover is at (1, 3) facing East. No Obstacles detected.

Features
--------
- Object-Oriented Design (Rover, Grid, Direction, Commands)
- Dynamic grid size
- Obstacle detection with exception handling
- Command parsing (M = Move, L = Turn Left, R = Turn Right)
- Easy to extend for visualization or multiple rovers

Future Enhancements
-------------------
- Display the grid after every move with rover and obstacles
- Support multiple rovers
- Add pathfinding to navigate around obstacles
- Add input from a file or GUI

design


