package com.yourcompany.marsrover.exception;

public class ObstacleDetectedException extends Exception {
    public ObstacleDetectedException(String message) {
        super(message);
    }
}
