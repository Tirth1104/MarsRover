package com.yourcompany.marsrover.grid;

import com.yourcompany.marsrover.model.Position;

public interface GridComponent {
    boolean hasObstacleAt(Position position);
}
