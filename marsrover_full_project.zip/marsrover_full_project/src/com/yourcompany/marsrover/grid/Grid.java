package com.yourcompany.marsrover.grid;

import com.yourcompany.marsrover.model.Position;
import java.util.ArrayList;
import java.util.List;

public class Grid implements GridComponent {
    private final int width;
    private final int height;
    private final List<GridComponent> components = new ArrayList<>();

    public Grid(int width, int height) {
        this.width = width;
        this.height = height;
    }

    public void addComponent(GridComponent component) {
        components.add(component);
    }

    @Override
    public boolean hasObstacleAt(Position position) {
        return components.stream().anyMatch(c -> c.hasObstacleAt(position));
    }

    public boolean isValid(Position position) {
        return position.x() >= 0 && position.x() < width &&
               position.y() >= 0 && position.y() < height;
    }
}
