package com.yourcompany.marsrover.grid;

import com.yourcompany.marsrover.model.Position;

public class Obstacle implements GridComponent {
    private final Position position;

    public Obstacle(Position position) {
        this.position = position;
    }

    @Override
    public boolean hasObstacleAt(Position position) {
        return this.position.equals(position);
    }
}
