package com.yourcompany.marsrover.core;

import com.yourcompany.marsrover.commands.Command;
import com.yourcompany.marsrover.exception.ObstacleDetectedException;
import com.yourcompany.marsrover.grid.Grid;
import com.yourcompany.marsrover.model.Direction;
import com.yourcompany.marsrover.model.Position;

import java.util.List;

public class Rover {
    private Position position;
    private Direction direction;
    private final Grid grid;

    public Rover(Position startPosition, Direction startDirection, Grid grid) {
        if (!grid.isValid(startPosition)) {
            throw new IllegalArgumentException("Initial rover position is out of bounds.");
        }
        this.position = startPosition;
        this.direction = startDirection;
        this.grid = grid;
        System.out.println("Rover initialized at " + position + " facing " + direction);
    }

    public void move() throws ObstacleDetectedException {
        Position newPosition = direction.moveForward(position);
        if (!grid.isValid(newPosition)) {
            System.err.println("Move aborted: Rover would go out of bounds.");
            return;
        }
        if (grid.hasObstacleAt(newPosition)) {
            throw new ObstacleDetectedException("Obstacle detected at " + newPosition);
        }
        this.position = newPosition;
    }

    public void turnLeft() {
        this.direction = this.direction.turnLeft();
    }

    public void turnRight() {
        this.direction = this.direction.turnRight();
    }

    public String getStatusReport() {
        return String.format("Rover is at (%d, %d) facing %s.",
                position.x(), position.y(), direction.toString());
    }
    public void processCommands(List<Command> commands) {
        for (Command command : commands) {
            try {
                command.execute(this);
            } catch (ObstacleDetectedException e) {
                System.err.println("⚠️ Execution stopped! " + e.getMessage());
                break;
            }
        }
    }
}
