package com.yourcompany.marsrover.commands;

import com.yourcompany.marsrover.core.Rover;

public class TurnLeftCommand implements Command {
    @Override
    public void execute(Rover rover) {
        rover.turnLeft();
    }
}
