package com.yourcompany.marsrover.commands;

import com.yourcompany.marsrover.core.Rover;
import com.yourcompany.marsrover.exception.ObstacleDetectedException;

public class MoveCommand implements Command {
    @Override
    public void execute(Rover rover) throws ObstacleDetectedException {
        rover.move();
    }
}
