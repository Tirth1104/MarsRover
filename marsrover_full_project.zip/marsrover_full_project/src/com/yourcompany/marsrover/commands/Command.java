package com.yourcompany.marsrover.commands;

import com.yourcompany.marsrover.core.Rover;
import com.yourcompany.marsrover.exception.ObstacleDetectedException;

public interface Command {
    void execute(Rover rover) throws ObstacleDetectedException;
}
