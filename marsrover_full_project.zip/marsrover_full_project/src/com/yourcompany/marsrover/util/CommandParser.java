package com.yourcompany.marsrover.util;

import com.yourcompany.marsrover.commands.Command;
import com.yourcompany.marsrover.commands.MoveCommand;
import com.yourcompany.marsrover.commands.TurnLeftCommand;
import com.yourcompany.marsrover.commands.TurnRightCommand;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class CommandParser {
    private static final Map<Character, Command> commandMap = Map.of(
            'M', new MoveCommand(),
            'L', new TurnLeftCommand(),
            'R', new TurnRightCommand()
    );

    public static List<Command> parse(String commandString) {
        return commandString.chars()
                .mapToObj(c -> (char) c)
                .map(commandMap::get)
                .collect(Collectors.toList());
    }
}
