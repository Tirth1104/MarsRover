package com.yourcompany.marsrover;

import com.yourcompany.marsrover.core.Rover;
import com.yourcompany.marsrover.commands.Command;
import com.yourcompany.marsrover.exception.ObstacleDetectedException;
import com.yourcompany.marsrover.grid.Grid;
import com.yourcompany.marsrover.grid.Obstacle;
import com.yourcompany.marsrover.model.North;
import com.yourcompany.marsrover.model.Position;
import com.yourcompany.marsrover.util.CommandParser;

import java.util.List;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Mars Rover Simulation Starting...");

        // Ask grid size
        System.out.print("Enter grid width: ");
        int width = scanner.nextInt();
        System.out.print("Enter grid height: ");
        int height = scanner.nextInt();
        Grid grid = new Grid(width, height);

        // Add some default obstacles or let user enter
        System.out.print("Enter number of obstacles: ");
        int numObstacles = scanner.nextInt();
        for (int i = 0; i < numObstacles; i++) {
            System.out.print("Enter obstacle " + (i+1) + " X: ");
            int ox = scanner.nextInt();
            System.out.print("Enter obstacle " + (i+1) + " Y: ");
            int oy = scanner.nextInt();
            grid.addComponent(new Obstacle(new Position(ox, oy)));
        }

        // Rover start position
        System.out.print("Enter rover starting X: ");
        int startX = scanner.nextInt();
        System.out.print("Enter rover starting Y: ");
        int startY = scanner.nextInt();
        // Facing north by default
        Rover rover = new Rover(new Position(startX, startY), North.getInstance(), grid);

        // Command string
        System.out.print("Enter rover commands (M,L,R): ");
        String commandString = scanner.next();

        // Parse & execute
        List<Command> commands = CommandParser.parse(commandString);
        System.out.println("Executing command sequence: " + commandString);

        for (Command command : commands) {
            try {
                command.execute(rover);
            } catch (ObstacleDetectedException e) {
                System.err.println("Execution stopped! " + e.getMessage());
                break;
            }
        }

        System.out.println("Simulation Finished.");
        System.out.println(rover.getStatusReport());
        scanner.close();
    }
}

