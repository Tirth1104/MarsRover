package com.yourcompany.marsrover.model;

public interface Direction {
    Direction turnLeft();
    Direction turnRight();
    Position moveForward(Position currentPosition);
}
