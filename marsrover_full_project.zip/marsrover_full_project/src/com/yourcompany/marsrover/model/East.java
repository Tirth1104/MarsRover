package com.yourcompany.marsrover.model;

public class East implements Direction {
    private static final East INSTANCE = new East();
    private East() {}
    public static East getInstance() { return INSTANCE; }
    @Override public Direction turnLeft() { return North.getInstance(); }
    @Override public Direction turnRight() { return South.getInstance(); }
    @Override public Position moveForward(Position pos) { return pos.move(1, 0); }
    @Override public String toString() { return "E"; }
}
