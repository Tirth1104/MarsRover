package com.yourcompany.marsrover.model;

public class North implements Direction {
    private static final North INSTANCE = new North();
    private North() {}

    public static North getInstance() {
        return INSTANCE;
    }

    @Override
    public Direction turnLeft() {
        return West.getInstance();
    }

    @Override
    public Direction turnRight() {
        return East.getInstance();
    }

    @Override
    public Position moveForward(Position pos) {
        return pos.move(0, 1);
    }

    @Override
    public String toString() { return "N"; }
}
