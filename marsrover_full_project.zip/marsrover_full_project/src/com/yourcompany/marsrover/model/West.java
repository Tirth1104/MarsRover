package com.yourcompany.marsrover.model;

public class West implements Direction {
    private static final West INSTANCE = new West();
    private West() {}
    public static West getInstance() { return INSTANCE; }
    @Override public Direction turnLeft() { return South.getInstance(); }
    @Override public Direction turnRight() { return North.getInstance(); }
    @Override public Position moveForward(Position pos) { return pos.move(-1, 0); }
    @Override public String toString() { return "W"; }
}
